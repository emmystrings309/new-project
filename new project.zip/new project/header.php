<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <header>

        <a href="#" class="logo">
            <h1>EMMY STRINGS</h1>
        </a>
        <nav class="nav__links">
            <ul>
                <li><a href="#" class="a">Home</a></li>
                <li><a href="#" class="a">About</a></li>
                <li><a href="#" class="a">Testimonials</a></li>
                <li style="padding-right: 100px;"><a href="#" class="a">Gallery</a></li>
            </ul>
        </nav>
        <form action="./include/login.inc.php" method="post">
            <input type="text" name="mailuid" placeholder="Username/Email..." required>
            <input type="password" name="pwd" placeholder="password..." required>
            <button type="submit" name="login-submit">login</button>
        </form>
        <a href="signup.php" Signup style="padding: 0;" class="a">Signup</a>
        <form action="./include/logout.inc.php" method="post">
            <button type="submit" name="logout-submit">logout</button>
        </form>
    </header>
</body>

</html>