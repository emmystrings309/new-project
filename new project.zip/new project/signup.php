<?php
require "header.php"

?>
<link rel="stylesheet" href="./css files/registerstyle.css">
<main>
    <div class="center">
        <section>
            <h1 class="word">Signup</h1>
            <div class="text_field">
                <form action="./include/signup.inc.php" method="post">
                    <input type="text" name="uid" placeholder="Username" class="input">
                    <input type="text" name="mail" placeholder="E-mail" class="input">
                    <input type="password" name="pwd" placeholder="Password" required class="input">
                    <input type="password" name="pwd-repeat" placeholder="Repeat password" required class="input">
                    <button type="submit" name="signup-submit" class="pass">Signup</button>
                </form>
            </div>
        </section>
    </div>

</main>



<?php
require "footer.php"

?>