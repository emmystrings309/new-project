<?php
require "header.php"

?>
<main>
    <?php
    if (isset($_SESSION['userId'])) {
        require "login.php";
    } else {
        require "./welcome/index.php";
    }
    ?>


</main>


<?php
require "footer.php"

?>