<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- <div> -->

    <head>
        <nav class="navbar">
            <a href="#" class="logo">
                <h1>EMMY STRINGS</h1>
            </a>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Home</a></li>
                <li><a href="#">Home</a></li>
                <li><a href="#">Home</a></li>
            </ul>
            <div>
                <form action="./include/login.inc.php" method="post">
                    <input type="text" name="maleuid" placeholder="Username/Email...">
                    <input type="text" name="pwd" placeholder="password...">
                    <button type="submit" name="login-submit">login</button>
                </form>
                <a href="signup.php" Signup></a>
                <form action="./include/logout.inc.php" method="post"></form>
                <button type="submit" name="logout-submit">logout</button>
            </div>
        </nav>


    </head>
    <!-- </div> -->
</body>

</html>