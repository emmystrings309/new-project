<?php
//to check if there is an input before any of this can run
if (isset($_POST['login-submit'])) {
//if confirmed require th database connection page
    require 'dbh.inc.php';
//input recieved from the form of the login
    $mailuid = $_POST['mailuid'];
    $password = $_POST['pwd'];
// checkng if anyone is left un filled
    if (empty($password) || empty($mailuid)) {
        header("Location: ../index.php?error=emptyfields");
        exit();
    }
} 
//if noone is left empty check for the confirmation process in the database 
else {
    $sql = "SELECT * FROM users WHERE uidUsers=? OR emailUsers=?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("Location: ../index.php?error=sqlerror");
        exit();
    } else {
        mysqli_stmt_bind_param($stmt, "ss", $mailuid, $mailuid);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_assoc($result)) {
            $pwdCheck = password_verify($password, $row['pwdUsers']);
            if ($pwdCheck == false) {
                header("Location: ../index.php?error=nouser");
                exit();
            } elseif ($pwdCheck == true) {
                //after all the checking for the information of the database with the one inputed if corresponding proceed 
                session_start();// where the session is started 
                $_SESSION['userId'] = $row['idUsers']; 
                $_SESSION['userUid'] = $row['uidUsers'];
                header("Location: ../index.php?login=success");
                exit();
            }
        } else {
            header("Location: ../index.php?error=nouser");
            exit();
        }
    }
}


//  else {
//      header("Location: ../index.php?error=sqlerror");
//      exit();
//     }
