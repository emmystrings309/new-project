<?php
//where my database is connected alongside the code
$servername = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "logintut";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
    die("connection failed:" . mysqli_connect_error());
}
